import torch
import torch.nn as nn
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
import requests
import base64
import io
import os
import copy
import time
from sklearn.metrics import accuracy_score, confusion_matrix


# CONFIG
SERVER_URL = "http://203.135.63.90:3000"

SFT_DIR = "../cifar10_raw/SFT"
TEST_DIR = "../cifar10_raw/test"

NUM_CLASSES = 10
BATCH_SIZE = 32
LOCAL_EPOCHS = 5
NUM_ROUNDS = 3
IMG_SIZE = 112
NUM_WORKERS = 0
DEVICE = "cpu"
DEVICE_TYPE = "PC"
LR = 0.001
GROUP_ID = input("Enter your Group ID: ")     # example group1

# TRANSFORMS
train_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
    transforms.RandomRotation(15),
    transforms.Normalize(
        [0.485, 0.456, 0.406],
        [0.229, 0.224, 0.225]
    )
])

test_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(
        [0.485, 0.456, 0.406],
        [0.229, 0.224, 0.225]
    )
])

# LOAD DATASET (GLOBAL CLASS MAP)
GLOBAL_CLASS_MAP = {str(i): i for i in range(10)}

def load_federated_dataset(path, transform):
    dataset = datasets.ImageFolder(path, transform=transform)
    dataset.class_to_idx = GLOBAL_CLASS_MAP

    new_samples = []
    for img_path, _ in dataset.samples:
        class_name = os.path.basename(os.path.dirname(img_path))
        new_samples.append((img_path, GLOBAL_CLASS_MAP[class_name]))

    dataset.samples = new_samples
    dataset.targets = [label for _, label in new_samples]
    return dataset


train_dataset = load_federated_dataset(SFT_DIR, train_transforms)
test_dataset = datasets.ImageFolder(TEST_DIR, test_transforms)

train_loader = DataLoader(train_dataset, BATCH_SIZE, shuffle=True, num_workers=NUM_WORKERS)
test_loader  = DataLoader(test_dataset,  BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS)

# MODEL FUNCTIONS
def build_model():
    model = models.squeezenet1_1(weights=models.SqueezeNet1_1_Weights.DEFAULT)
    model.classifier[1] = nn.Conv2d(512, NUM_CLASSES, kernel_size=1)
    model.num_classes = NUM_CLASSES
    return model

# TRAIN LOCAL MODEL
def local_train(model):
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=LR)

    for epoch in range(LOCAL_EPOCHS):
        model.train()
        total_loss = 0
        for images, labels in train_loader:
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"Local Epoch {epoch+1}/{LOCAL_EPOCHS} Loss = {total_loss/len(train_loader):.4f}")

    return model

# SERIALIZE / DESERIALIZE WEIGHTS
def serialize_state(state_dict):
    buf = io.BytesIO()
    torch.save(state_dict, buf)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def deserialize_state(b64_str):
    data = base64.b64decode(b64_str)
    buf = io.BytesIO(data)
    return torch.load(buf, map_location="cpu")


# EVALUATION
def evaluate(model):
    model.eval()
    all_preds, all_labels = [], []
    with torch.no_grad():
        for images, labels in test_loader:
            outputs = model(images)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    acc = accuracy_score(all_labels, all_preds)
    print("\nConfusion Matrix:\n", confusion_matrix(all_labels, all_preds))
    print("Accuracy = %.2f%%" % (acc * 100))
    return acc

# MAIN LOOP (FL ROUNDS)
print("\n===== STARTING FEDERATED LEARNING CLIENT =====")

model = build_model().cpu()

for rnd in range(NUM_ROUNDS):

    print(f"\n========== ROUND {rnd+1}/{NUM_ROUNDS} ==========")


    # Local Training

    print("\nLocal training started...")
    model = local_train(model)

    # Upload local weights to server
    torch.save(model.state_dict(), "local_weights.pth")

    with open("local_weights.pth", "rb") as f:
        res = requests.post(
            f"{SERVER_URL}/upload_weights",
            data={
                "group_id": GROUP_ID,
                "round_number": rnd,
                "device_type": DEVICE_TYPE
            },
            files={"file": f}
        )

    print("\nUploaded local model:", res.json())


    # Evaluate the local model


    print("\nEvaluating your local model...")
    evaluate(model)

    # Get latest global model from server


    print("\nPress ENTER to download global model for this round...")
    input()

    res = requests.get(
        f"{SERVER_URL}/get_global",
        params={"group_id": GROUP_ID, "round_number": rnd}
    )
    if res.json()["status"] == "success":
        global_weights = deserialize_state(res.json()["global_model_b64"])
        model.load_state_dict(global_weights)
        print("Global model downloaded.")
    else:
        print("Server: No global model found, starting from initial model.")

    print("\nEvaluating your global model...")
    evaluate(model)

print("\n===== TRAINING FINISHED =====")
