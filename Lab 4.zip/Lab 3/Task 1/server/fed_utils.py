import torch
import base64
import io
import os
import copy

def serialize_state_dict(state_dict):
    """Convert PyTorch state_dict → base64 string."""
    buffer = io.BytesIO()
    torch.save(state_dict, buffer)
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode()

def deserialize_state_dict(b64_str):
    """Convert base64 string → PyTorch state_dict."""
    binary = base64.b64decode(b64_str.encode())
    buffer = io.BytesIO(binary)
    state_dict = torch.load(buffer, map_location="cpu")
    return state_dict

def fedavg(weight_list):
    """Simple FedAvg: average a list of state_dicts."""
    avg_weights = copy.deepcopy(weight_list[0])
    for key in avg_weights.keys():
        avg_weights[key] = weight_list[0][key].clone()
        for i in range(1, len(weight_list)):
            avg_weights[key] += weight_list[i][key]
        avg_weights[key] = avg_weights[key] / len(weight_list)
    return avg_weights

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)