# main.py
from fastapi import FastAPI, Form, UploadFile, File
from fastapi.responses import JSONResponse
import os
import uuid
import torch

from fed_utils import (
    serialize_state_dict,
    deserialize_state_dict,
    fedavg,
    ensure_dir
)

app = FastAPI(title="FL Server")

WEIGHT_DIR = "weights_store"
GLOBAL_DIR = "global_models"
METADATA_FILE = "metadata.txt"

ensure_dir(WEIGHT_DIR)
ensure_dir(GLOBAL_DIR)


# 1) SAVE METADATA TO TEXT

def log_metadata(group_id, round_number, filepath):
    with open(METADATA_FILE, "a") as f:
        f.write(f"{group_id},{round_number},{filepath}\n")



# 2) POST UPLOAD WEIGHTS

@app.post("/upload_weights")
async def upload_weights(
    group_id: str = Form(...),
    round_number: int = Form(...),
    device_type: str = Form(...),
    file: UploadFile = File(...)
):
    save_dir = f"{WEIGHT_DIR}/{group_id}/{round_number}/"
    ensure_dir(save_dir)

    filename = f"{device_type}_{uuid.uuid4().hex}.pth"
    file_path = os.path.join(save_dir, filename)

    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())

    log_metadata(group_id, round_number, file_path)

    return {"status": "success", "file": file_path}

@app.post("/aggregate")
async def aggregate(round_number: int = None):

    weight_files = []

    # Load metadata
    with open(METADATA_FILE, "r") as f:
        for line in f:
            gid, rnd, file_path = line.strip().split(",")
            if int(rnd) == round_number:
                weight_files.append(file_path)

    if not weight_files:
        return {"status": "error", "message": "No weights uploaded."}

    # Load all client weight files
    weight_list = []
    for fpath in weight_files:
        sd = torch.load(fpath, map_location="cpu")
        weight_list.append(sd)

    # FedAvg
    global_state = fedavg(weight_list)

    # Save global model
    global_path = f"{GLOBAL_DIR}/round{round_number}_global.pth"
    torch.save(global_state, global_path)

    return {
        "status": "success",
        "global_model_path": global_path,
        "num_clients": len(weight_list)
    }


@app.get("/get_global")
async def get_global(group_id: str, round_number: int):

    global_path = f"{GLOBAL_DIR}/round{round_number}_global.pth"

    if not os.path.exists(global_path):
        return {"status": "error", "message": "Global model not found"}

    state_dict = torch.load(global_path, map_location="cpu")
    b64 = serialize_state_dict(state_dict)

    return {
        "status": "success",
        "group_id": group_id,
        "round_number": round_number,
        "global_model_b64": b64
    }
