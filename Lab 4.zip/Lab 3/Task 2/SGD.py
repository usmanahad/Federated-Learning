import torch
import torch.nn as nn
import torch.optim as optim
import torch.multiprocessing as mp
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
import copy
from sklearn.metrics import accuracy_score, confusion_matrix
import numpy as np
import os
import time


# CONFIG

TEST_DIR = "../cifar10_raw/test"
SFT_DIR1 = "../cifar10_raw/SFT1"
SFT_DIR2 = "../cifar10_raw/SFT2"

NUM_CLASSES = 10
BATCH_SIZE = 32
NUM_ROUNDS = 15                # FedSGD uses MANY rounds
LR = 0.001                     # Server learning rate
NUM_WORKERS = 2
DEVICE = "cpu"
IMG_SIZE = 112

# TRANSFORMS

train_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

test_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])



# FIX LABEL MAPPING FOR FEDERATED CLIENTS

GLOBAL_CLASS_MAP = {str(i): i for i in range(10)}

def load_federated_dataset(path, transform):
    dataset = datasets.ImageFolder(path, transform=transform)
    dataset.class_to_idx = GLOBAL_CLASS_MAP

    new_samples = []
    for img_path, _ in dataset.samples:
        class_name = os.path.basename(os.path.dirname(img_path))
        new_samples.append((img_path, GLOBAL_CLASS_MAP[class_name]))

    dataset.samples = new_samples
    dataset.targets = [label for _, label in new_samples]

    return dataset



# LOAD DATASETS

train_dataset1 = load_federated_dataset(SFT_DIR1, train_transforms)
train_dataset2 = load_federated_dataset(SFT_DIR2, train_transforms)

train_loader1 = DataLoader(train_dataset1, batch_size=BATCH_SIZE, shuffle=True, num_workers=NUM_WORKERS)
train_loader2 = DataLoader(train_dataset2, batch_size=BATCH_SIZE, shuffle=True, num_workers=NUM_WORKERS)

train_loaders = [train_loader1, train_loader2]
train_sizes = [len(train_dataset1), len(train_dataset2)]

test_dataset = datasets.ImageFolder(TEST_DIR, transform=test_transforms)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS)



# CLIENT: COMPUTE GRADIENTS (FedSGD)

def client_compute_gradients(rank, global_weights, loader, return_dict):
    model = models.squeezenet1_1(weights=models.SqueezeNet1_1_Weights.DEFAULT)
    model.classifier[1] = nn.Conv2d(512, NUM_CLASSES, kernel_size=1)
    model.num_classes = NUM_CLASSES

    model.load_state_dict(global_weights)
    model.cpu()
    model.train()

    criterion = nn.CrossEntropyLoss()

    # Take only ONE batch (FedSGD)
    images, labels = next(iter(loader))
    images, labels = images.to("cpu"), labels.to("cpu")

    # Compute gradients
    model.zero_grad()
    outputs = model(images)
    loss = criterion(outputs, labels)
    loss.backward()

    # Collect gradient dictionary
    grad_dict = {name: param.grad.clone() for name, param in model.named_parameters()}

    print(f"[Client {rank}] FedSGD Loss: {loss.item():.4f}")
    return_dict[rank] = grad_dict



# SERVER: APPLY FedSGD UPDATE

def fedsgd_update(global_model, client_grads, client_sizes, lr=LR):
    total = sum(client_sizes)

    with torch.no_grad():
        for name, param in global_model.named_parameters():
            # Weighted gradient average
            avg_grad = sum(
                (client_sizes[i] / total) * client_grads[i][name]
                for i in range(len(client_grads))
            )
            # SGD step
            param -= lr * avg_grad



# EVALUATION

def evaluate(model, loader):
    model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for images, labels in loader:
            outputs = model(images)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    acc = accuracy_score(all_labels, all_preds)
    cm = confusion_matrix(all_labels, all_preds)

    print("\nConfusion Matrix:")
    print(cm)

    return acc



# MAIN FEDERATED ROUNDS

if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)

    # Initialize global model
    global_model = models.squeezenet1_1(weights=models.SqueezeNet1_1_Weights.DEFAULT)
    global_model.classifier[1] = nn.Conv2d(512, NUM_CLASSES, kernel_size=1)
    global_model.num_classes = NUM_CLASSES
    global_model.cpu()

    print("\n START FEDSGD TRAINING")
    start_time = time.time()
    for rnd in range(NUM_ROUNDS):
        print(f"\n FedSGD Round {rnd+1}/{NUM_ROUNDS}")

        manager = mp.Manager()
        return_dict = manager.dict()
        processes = []

        global_weights = copy.deepcopy(global_model.state_dict())

        # Run clients in parallel
        for cid in range(2):
            p = mp.Process(
                target=client_compute_gradients,
                args=(cid, global_weights, train_loaders[cid], return_dict)
            )
            p.start()
            processes.append(p)

        for p in processes:
            p.join()

        # Gather gradients
        client_grads = list(return_dict.values())

        # Server updates global model using FedSGD
        fedsgd_update(global_model, client_grads, train_sizes, lr=LR)

        # Evaluate
        acc = evaluate(global_model, test_loader)
        print(f"Global Model Accuracy after Round {rnd+1}: {acc*100:.2f}%")

    print("\n FedSGD TRAINING COMPLETE")
    print("Training Time: %.2f minutes" % ((time.time() - start_time)/60))

