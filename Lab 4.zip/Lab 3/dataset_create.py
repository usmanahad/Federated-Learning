import os
import shutil
import random

# Path to your existing test folder
test_dir = "./cifar10_raw/train"

# Output folders
sft_dir = "./cifar10_raw/SFT"



# Create output base folders
os.makedirs(sft_dir, exist_ok=True)


# Iterate through class folders: 0,1,2,... etc
for class_name in os.listdir(test_dir):
    class_path = os.path.join(test_dir, class_name)

    # Skip non-folder files
    if not os.path.isdir(class_path):
        continue

    # Create matching class subfolders
    os.makedirs(os.path.join(sft_dir, class_name), exist_ok=True)


    # List image files for this class
    images = [f for f in os.listdir(class_path)
              if f.lower().endswith((".png", ".jpg", ".jpeg"))]

    # Shuffle the images
    random.seed(14)
    random.shuffle(images)

    # Split 50/50
    # mid = len(images) // 2
    mid= 100
    sft_imgs = images[:mid]

    # Copy files into respective folders
    for img in sft_imgs:
        shutil.copy(os.path.join(class_path, img),
                    os.path.join(sft_dir, class_name, img))


    print(f"Class {class_name}: {len(images)} total → "
          f"{len(sft_imgs)} SFT")

print("\nDone! Folder structure created successfully.")
